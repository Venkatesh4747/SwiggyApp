"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_home_home_module_ts"],{

/***/ 3949:
/*!*********************************************!*\
  !*** ./src/app/home/home-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageRoutingModule": () => (/* binding */ HomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 7464);




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage,
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], HomePageRoutingModule);



/***/ }),

/***/ 8245:
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageModule": () => (/* binding */ HomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 7464);
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home-routing.module */ 3949);







let HomePageModule = class HomePageModule {
};
HomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _home_routing_module__WEBPACK_IMPORTED_MODULE_1__.HomePageRoutingModule
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage]
    })
], HomePageModule);



/***/ }),

/***/ 7464:
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePage": () => (/* binding */ HomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _home_twilightuser_Documents_Ionic_Project_SwiggyApp_swiggy_app_node_modules_ngtools_webpack_src_loaders_direct_resource_js_home_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./home.page.html */ 2056);
/* harmony import */ var _home_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page.scss */ 968);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);




let HomePage = class HomePage {
    constructor() {
        this.foodSlideOptions = {
            slidesPerView: 2.5,
            spaceBetween: 5,
            slidesPerColumn: 2
        };
        this.offer = {
            slidesPerView: 1,
            spaceBetween: 0,
            pager: true
        };
        this.food = [
            {
                hotelName: 'Banana Leaf',
                rating: 4.3,
                imageUrl: 'assets/images/biryani.jpg',
                mins: '46 mins'
            },
            {
                hotelName: 'Cake World',
                rating: '4.0',
                imageUrl: 'assets/images/cake.jpg',
                mins: '35 mins'
            },
            {
                hotelName: 'Juice Shop',
                rating: '4.5',
                imageUrl: 'assets/images/juice.jpeg',
                mins: '20 mins'
            },
            {
                hotelName: 'KFC',
                rating: '4.1',
                imageUrl: 'assets/images/kfc.jpg',
                mins: '40 mins'
            },
            {
                hotelName: 'BBQ',
                rating: '4.0',
                imageUrl: 'assets/images/bbq.jpeg',
                mins: '35 mins'
            },
            {
                hotelName: 'Cake World',
                rating: '4.0',
                imageUrl: 'assets/images/cake.jpg',
                mins: '35 mins'
            },
            {
                hotelName: 'KFC',
                rating: '4.1',
                imageUrl: 'assets/images/kfc.jpg',
                mins: '40 mins'
            },
            {
                hotelName: 'Cake World',
                rating: '4.0',
                imageUrl: 'assets/images/cake.jpg',
                mins: '35 mins'
            },
        ];
        this.popularItem = [
            {
                foodName: 'Burger',
                imageUrl: 'assets/images/pop1.jpeg',
            },
            {
                foodName: 'Salad',
                imageUrl: 'assets/images/pop1.jpeg',
            },
            {
                foodName: 'kebabs',
                imageUrl: 'assets/images/pop1.jpeg',
            },
            {
                foodName: 'Dessert',
                imageUrl: 'assets/images/pop3.png',
            },
            {
                foodName: 'Sandwiches',
                imageUrl: 'assets/images/pop3.png',
            },
            {
                foodName: 'Plums',
                imageUrl: 'assets/images/pop3.png',
            },
        ];
        this.todayOffer = [
            {
                imageUrl: 'assets/images/off1.png',
            },
            {
                imageUrl: 'assets/images/off2.jpg',
            },
            {
                imageUrl: 'assets/images/off1.jpg',
            },
            {
                imageUrl: 'assets/images/off4.jpg',
            },
            {
                imageUrl: 'assets/images/off5.png',
            },
            {
                imageUrl: 'assets/images/off6.png',
            },
        ];
    }
};
HomePage.ctorParameters = () => [];
HomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-home',
        template: _home_twilightuser_Documents_Ionic_Project_SwiggyApp_swiggy_app_node_modules_ngtools_webpack_src_loaders_direct_resource_js_home_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_home_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], HomePage);



/***/ }),

/***/ 2056:
/*!****************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/home/home.page.html ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>Swiggy</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-card class=\"border\">\n    <ion-grid>\n      <ion-row>\n        <ion-col size=\"8\">\n          <ion-card-header>\n            <ion-card-title>Restaurants</ion-card-title>\n            <ion-label>Enjoy your favourite treats</ion-label>\n          </ion-card-header>\n          <ion-card-content class=\"center\">\n            <ion-text color=\"dark\">View All</ion-text>\n            <ion-icon class=\"icon\" color=\"dark\" name=\"arrow-forward-outline\"></ion-icon>\n          </ion-card-content>\n        </ion-col>\n        <ion-col class=\"background-image\">\n\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-card>\n\n  <div class=\"flex\">\n    <div class=\"bg-color\">\n    </div>\n    <div class=\"margin\">\n      <ion-text>We're here to help. Our restaurant and essential\n        delivery services are open from:\n      </ion-text>\n      <ion-text class=\"text-color\">7.00 AM - 1.00 AM</ion-text>\n    </div>\n  </div>\n\n  <ion-card color=\"warning\">\n    <ion-img src=\"../../assets/images/food3.jpeg\"></ion-img>\n  </ion-card>\n\n  <div class=\"flex-pad\">\n    <div>\n      <ion-icon color=\"warning\" class=\"icon-size\" name=\"thumbs-up-outline\"></ion-icon>\n    </div>\n    <div>\n      <ion-text color=\"dark\">\n        <h4 class=\"mar-top\">Top Picks For You</h4>\n      </ion-text>\n    </div>\n  </div>\n\n  <ion-slides [options]=\"foodSlideOptions\">\n    <ion-slide *ngFor=\"let foods of food\">\n      <div class=\"flex-content\">\n        <div>\n          <ion-card class=\"card-size\">\n            <img [src]=\"foods.imageUrl\">\n          </ion-card>\n        </div>\n        <div class=\"flex-content\">\n          <div class=\"align-content\">\n            <ion-text>{{ foods.hotelName }}</ion-text>\n          </div>\n          <div class=\"rateimg\">\n            <ion-icon name=\"star-outline\">\n            </ion-icon>\n            <ion-text>{{foods.rating}} . {{foods.mins}}</ion-text>\n          </div>\n        </div>\n      </div>\n    </ion-slide>\n  </ion-slides>\n\n  <ion-card class=\"margin-size\">\n    <ion-card-header>\n      <ion-card-title>Popular Creations</ion-card-title>\n    </ion-card-header>\n    <ion-card-content class=\"ion-no-padding margin-size\">\n      <ion-slides [options]=\"foodSlideOptions\">\n        <ion-slide *ngFor=\"let foods of popularItem\">\n          <div class=\"flex-content\">\n            <img class=\"card-popular\" [src]=\"foods.imageUrl\">\n            <ion-text>{{ foods.foodName }}</ion-text>\n          </div>\n        </ion-slide>\n      </ion-slides>\n    </ion-card-content>\n  </ion-card>\n\n  <ion-card class=\"margin-size-spot\">\n    <in-card-header>\n      <ion-card-title class=\"text-align\">\n        <ion-icon name=\"home-outline\"></ion-icon>\n        <ion-text class=\"text-align\">In the Spotlight!</ion-text>\n      </ion-card-title>\n      <ion-card-subtitle>\n        <ion-text class=\"text-align\">Explore sponsored partner brands</ion-text>\n      </ion-card-subtitle>\n    </in-card-header>\n    <ion-slides [options]=\"foodSlideOptions\">\n      <ion-slide *ngFor=\"let foods of food\">\n        <div class=\"flex-content\">\n          <div>\n            <ion-card class=\"card-size\">\n              <img [src]=\"foods.imageUrl\">\n            </ion-card>\n          </div>\n          <div class=\"flex-content\">\n            <div class=\"align-content\">\n              <ion-text>{{ foods.hotelName }}</ion-text>\n            </div>\n            <div class=\"rateimg\">\n              <ion-icon name=\"star-outline\">\n              </ion-icon>\n              <ion-text>{{foods.rating}} . {{foods.mins}}</ion-text>\n            </div>\n          </div>\n        </div>\n      </ion-slide>\n    </ion-slides>\n  </ion-card>\n\n  <!-- <ion-card>\n    <ion-card-header>\n      <ion-card-title>Today's Featured</ion-card-title>\n    </ion-card-header>\n    <ion-card-content class=\"ion-no-padding\">\n      <ion-slides loop=\"false\" speed=\"500\" pager=\"true\" spaceBetween=\"0\" direction=\"vertical\" slidesPerView=\"2\" effect=\"slide\" pager=\"false\" zoom=\"false\">\n        <ion-slide *ngFor=\"let foods of todayOffer\">\n          <ion-card>\n            <img [src]=\"foods.imageUrl\">\n          </ion-card>\n        </ion-slide>\n      </ion-slides>\n    </ion-card-content>\n  </ion-card> -->");

/***/ }),

/***/ 968:
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/***/ ((module) => {

module.exports = ".center {\n  display: flex;\n  align-items: center;\n}\n\n.icon {\n  font-size: 20px;\n  width: 23px;\n}\n\n.border {\n  border-radius: 15px;\n}\n\n.flex {\n  display: flex;\n  padding: 11px;\n}\n\n.bg-color {\n  background: brown;\n  width: 19px;\n  height: 78px;\n  border-bottom-right-radius: 10px;\n  border-top-right-radius: 10px;\n}\n\n.margin {\n  padding: 8px;\n  margin-left: 10px;\n  display: flex;\n  flex-direction: column;\n}\n\n.text-color {\n  color: gray;\n}\n\n.mar-top {\n  margin-top: 10px;\n  margin-left: 10px;\n  font-weight: bolder;\n}\n\n.flex-pad {\n  display: flex;\n  padding: 19px;\n  align-items: center;\n  margin-top: -24px;\n}\n\n.icon-size {\n  font-size: 21px;\n}\n\nion-card-title {\n  font-weight: 500;\n  font-size: 22px;\n}\n\n:host .background-image {\n  background: url('food2.jpeg');\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: contain;\n}\n\n:host ::ng-deep .swiper-wrapper {\n  align-items: center !important;\n  justify-content: center !important;\n}\n\n:host ::ng-deep .margin-size {\n  margin: 0%;\n}\n\n:host ::ng-deep md.margin-size {\n  margin: 0%;\n  margin-top: 10px;\n}\n\n:host ::ng-deep .margin-size-spot {\n  margin: 0%;\n  margin-top: 15px;\n}\n\n.card-size {\n  width: 100%;\n  height: 100px;\n  border-radius: 10px;\n}\n\nimg {\n  object-fit: cover;\n  width: 100%;\n  height: 100%;\n}\n\n.swiper-slide {\n  width: auto;\n}\n\n.ios .align-content {\n  margin-top: -10px;\n  font-size: 16px;\n  float: left;\n  margin-left: 15px;\n  font-weight: 500;\n  display: flex;\n  flex-direction: column;\n  width: -moz-fit-content;\n  width: fit-content;\n}\n\n.md .align-content {\n  font-weight: 500;\n  margin-top: 10px;\n  font-size: 16px;\n  float: left;\n  margin-left: 15px;\n  display: flex;\n  flex-direction: column;\n  width: -moz-fit-content;\n  width: fit-content;\n}\n\n.rateimg {\n  font-size: 11px;\n  margin-top: 6px;\n  width: -moz-fit-content;\n  width: fit-content;\n  margin-left: 15px;\n}\n\n.flex-content {\n  display: flex;\n  flex-direction: column;\n}\n\n.card-popular {\n  border-radius: 50px;\n}\n\n.text-align {\n  margin-left: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0FBQ0Y7O0FBRUE7RUFDRSxlQUFBO0VBQ0EsV0FBQTtBQUNGOztBQUVBO0VBQ0UsbUJBQUE7QUFDRjs7QUFFQTtFQUNFLGFBQUE7RUFDQSxhQUFBO0FBQ0Y7O0FBRUE7RUFDRSxpQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZ0NBQUE7RUFDQSw2QkFBQTtBQUNGOztBQUVBO0VBQ0UsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxXQUFBO0FBRUY7O0FBQ0E7RUFDRSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7QUFFRjs7QUFDQTtFQUNFLGFBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBQUVGOztBQUNBO0VBQ0UsZUFBQTtBQUVGOztBQUNBO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0FBRUY7O0FBRUU7RUFDRSw2QkFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7RUFDQSx3QkFBQTtBQUNKOztBQUdFO0VBQ0UsOEJBQUE7RUFDQSxrQ0FBQTtBQUFKOztBQUVFO0VBQ0UsVUFBQTtBQUFKOztBQUVFO0VBQ0UsVUFBQTtFQUNBLGdCQUFBO0FBQUo7O0FBRUU7RUFDRSxVQUFBO0VBQ0EsZ0JBQUE7QUFBSjs7QUFLQTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUFGRjs7QUFJQTtFQUNFLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUFERjs7QUFHQTtFQUNFLFdBQUE7QUFBRjs7QUFHQTtFQUNFLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsdUJBQUE7RUFBQSxrQkFBQTtBQUFGOztBQUdBO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSx1QkFBQTtFQUFBLGtCQUFBO0FBQUY7O0FBR0E7RUFDRSxlQUFBO0VBQ0EsZUFBQTtFQUNBLHVCQUFBO0VBQUEsa0JBQUE7RUFDQSxpQkFBQTtBQUFGOztBQUdBO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0FBQUY7O0FBR0E7RUFDRSxtQkFBQTtBQUFGOztBQUdBO0VBQ0UsaUJBQUE7QUFBRiIsImZpbGUiOiJob21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jZW50ZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuXG4uaWNvbiB7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgd2lkdGg6IDIzcHg7XG59XG5cbi5ib3JkZXIge1xuICBib3JkZXItcmFkaXVzOiAxNXB4O1xufVxuXG4uZmxleCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIHBhZGRpbmc6IDExcHg7XG59XG5cbi5iZy1jb2xvciB7XG4gIGJhY2tncm91bmQ6IGJyb3duO1xuICB3aWR0aDogMTlweDtcbiAgaGVpZ2h0OiA3OHB4O1xuICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMTBweDtcbiAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDEwcHg7XG59XG5cbi5tYXJnaW4ge1xuICBwYWRkaW5nOiA4cHg7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xufVxuLnRleHQtY29sb3Ige1xuICBjb2xvcjogZ3JheTtcbn1cblxuLm1hci10b3Age1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcbn1cblxuLmZsZXgtcGFkIHtcbiAgZGlzcGxheTogZmxleDtcbiAgcGFkZGluZzogMTlweDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgbWFyZ2luLXRvcDogLTI0cHg7XG59XG5cbi5pY29uLXNpemUge1xuICBmb250LXNpemU6IDIxcHg7XG59XG5cbmlvbi1jYXJkLXRpdGxlIHtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgZm9udC1zaXplOiAyMnB4O1xufVxuXG46aG9zdCB7XG4gIC5iYWNrZ3JvdW5kLWltYWdlIHtcbiAgICBiYWNrZ3JvdW5kOiB1cmwoXCIuLi8uLi9hc3NldHMvaW1hZ2VzL2Zvb2QyLmpwZWdcIik7XG4gICAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gICAgYmFja2dyb3VuZC1zaXplOiBjb250YWluO1xuICB9XG59XG46aG9zdCA6Om5nLWRlZXAge1xuICAuc3dpcGVyLXdyYXBwZXIge1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXIgIWltcG9ydGFudDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlciAhaW1wb3J0YW50O1xuICB9XG4gIC5tYXJnaW4tc2l6ZSB7XG4gICAgbWFyZ2luOiAwJTtcbiAgfVxuICBtZC5tYXJnaW4tc2l6ZSB7XG4gICAgbWFyZ2luOiAwJTtcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICB9XG4gIC5tYXJnaW4tc2l6ZS1zcG90IHtcbiAgICBtYXJnaW46IDAlO1xuICAgIG1hcmdpbi10b3A6IDE1cHg7XG4gIH1cblxufVxuXG4uY2FyZC1zaXplIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG5pbWcge1xuICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbn1cbi5zd2lwZXItc2xpZGUge1xuICB3aWR0aDogYXV0bztcbn1cblxuLmlvcyAuYWxpZ24tY29udGVudCB7XG4gIG1hcmdpbi10b3A6IC0xMHB4O1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZsb2F0OiBsZWZ0O1xuICBtYXJnaW4tbGVmdDogMTVweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgd2lkdGg6IGZpdC1jb250ZW50O1xufVxuXG4ubWQgLmFsaWduLWNvbnRlbnQge1xuICBmb250LXdlaWdodDogNTAwO1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZsb2F0OiBsZWZ0O1xuICBtYXJnaW4tbGVmdDogMTVweDtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgd2lkdGg6IGZpdC1jb250ZW50O1xufVxuXG4ucmF0ZWltZyB7XG4gIGZvbnQtc2l6ZTogMTFweDtcbiAgbWFyZ2luLXRvcDogNnB4O1xuICB3aWR0aDogZml0LWNvbnRlbnQ7XG4gIG1hcmdpbi1sZWZ0OiAxNXB4O1xufVxuXG4uZmxleC1jb250ZW50IHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbn1cblxuLmNhcmQtcG9wdWxhciB7XG4gIGJvcmRlci1yYWRpdXM6IDUwcHg7XG59XG5cbi50ZXh0LWFsaWduIHtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG59XG5cbiJdfQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_home_home_module_ts.js.map